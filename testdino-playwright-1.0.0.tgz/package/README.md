# @testdino/playwright

[![npm version](https://img.shields.io/npm/v/@testdino/playwright.svg)](https://www.npmjs.com/package/@testdino/playwright)
[![Node.js](https://img.shields.io/badge/Node.js-%3E%3D18.0.0-green.svg)](https://nodejs.org/)

Real-time streaming reporter and CLI for Playwright that captures comprehensive test execution data and streams it to [TestDino](https://www.testdino.com) for advanced analytics and insights.

**[Website](https://www.testdino.com)** | **[Documentation](https://www.testdino.com/docs)** | **[Get Your Token](https://www.testdino.com/docs/getting-started)**

## Features

- **Real-time Streaming** - See your test results as they happen
- **Rich Metadata** - Automatic collection of Git, CI, System, and Playwright environment data
- **Distributed Testing** - Full support for sharded test execution across multiple machines
- **Production-Ready** - Built-in retry logic and graceful error handling
- **Zero Configuration** - Works out of the box with sensible defaults
- **Flexible Integration** - Use as a CLI wrapper or native Playwright reporter
- **Complete Visibility** - Captures test runs, individual tests, steps, errors, and console output

## Installation

```bash
npm install --save-dev @testdino/playwright
```

**Requirements:**

- Node.js >= 18.0.0
- @playwright/test >= 1.50.0

## Quick Start

### Using the CLI (Recommended)

The `tdpw` CLI wraps Playwright's test runner, automatically configuring the TestDino reporter while passing all other options directly to Playwright.

```bash
npx tdpw test [testdino-options] [playwright-options] [test-files]
```

**Basic usage:**

```bash
# Set your token (get one at testdino.com)
export TESTDINO_TOKEN=your_token

# Run all tests
npx tdpw test

# Or pass token directly
npx tdpw test --token YOUR_TOKEN
```

**With Playwright options:**

Any option not recognized by TestDino is passed through to Playwright:

```bash
# Run specific test file
npx tdpw test tests/login.spec.ts

# Run in headed mode with specific browser
npx tdpw test --headed --project=chromium

# Run tests matching a pattern
npx tdpw test --grep "authentication"

# Run with multiple workers
npx tdpw test --workers=4

# Run in Playwright UI mode
npx tdpw test --ui

# Run with retries
npx tdpw test --retries=2

# Sharded execution
npx tdpw test --shard=1/3
```

**Common Playwright options:**

| Option              | Description                   |
| ------------------- | ----------------------------- |
| `--headed`          | Run in headed browser mode    |
| `--ui`              | Open Playwright UI mode       |
| `--debug`           | Run with Playwright Inspector |
| `--project=<name>`  | Run specific project          |
| `--grep=<pattern>`  | Filter tests by title         |
| `--workers=<n>`     | Number of parallel workers    |
| `--retries=<n>`     | Retry failed tests            |
| `--shard=<x/y>`     | Shard tests across machines   |
| `--timeout=<ms>`    | Test timeout                  |
| `--reporter=<name>` | Add additional reporters      |

For all Playwright options, see the [Playwright CLI documentation](https://playwright.dev/docs/test-cli).

### Using as a Playwright Reporter

Alternatively, add TestDino directly to your Playwright configuration:

```typescript
// playwright.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  reporter: [
    ['@testdino/playwright', { token: process.env.TESTDINO_TOKEN }],
    ['html'], // Combine with other reporters
  ],
});
```

Then run tests with standard Playwright command:

```bash
npx playwright test
```

## Configuration

### TestDino Options

| Option    | CLI Flag        | Environment Variable | Description                     |
| --------- | --------------- | -------------------- | ------------------------------- |
| `token`   | `--token`, `-t` | `TESTDINO_TOKEN`     | Authentication token (required) |
| `debug`   | `--debug`       | `TESTDINO_DEBUG`     | Enable debug logging            |
| `ciRunId` | `--ci-run-id`   | -                    | Group sharded test runs         |

### Configuration File

Create `testdino.config.ts` (or `.js`) in your project root for persistent settings:

```typescript
// testdino.config.ts
export default {
  token: process.env.TESTDINO_TOKEN,
  debug: false,
};
```

```javascript
// testdino.config.js
module.exports = {
  token: process.env.TESTDINO_TOKEN,
};
```

**Dynamic configuration:**

```typescript
export default function () {
  return {
    token: process.env.TESTDINO_TOKEN,
    debug: !process.env.CI,
  };
}
```

### Configuration Priority

Settings are applied in this order (highest to lowest):

1. CLI flags (`--token`)
2. Config file (`testdino.config.ts`)
3. Playwright config (reporter options)
4. Environment variables (`TESTDINO_TOKEN`)

## CI/CD Integration

### GitHub Actions

```yaml
name: E2E Tests
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'

      - run: npm ci
      - run: npx playwright install --with-deps

      - name: Run tests
        env:
          TESTDINO_TOKEN: ${{ secrets.TESTDINO_TOKEN }}
        run: npx tdpw test
```

### GitLab CI

```yaml
e2e-tests:
  image: mcr.microsoft.com/playwright:v1.50.0-jammy
  script:
    - npm ci
    - npx tdpw test
  variables:
    TESTDINO_TOKEN: $TESTDINO_TOKEN
```

### Sharded Execution

TestDino automatically detects shard information:

```yaml
# GitHub Actions matrix example
jobs:
  test:
    strategy:
      matrix:
        shard: [1/3, 2/3, 3/3]
    steps:
      - run: npx tdpw test --shard=${{ matrix.shard }}
```

## Metadata Collection

TestDino automatically collects environment metadata at the start of each test run:

| Category   | Information Collected                           |
| ---------- | ----------------------------------------------- |
| Git        | Branch, commit, author, message, repository URL |
| CI         | Provider, build ID, PR details (GitHub Actions) |
| System     | OS, CPU, memory, Node.js version                |
| Playwright | Version, workers, projects, shard info          |

Metadata collection is non-blocking. Tests continue even if some metadata is unavailable.

## Troubleshooting

### Token Error

```
Token is required but not provided
```

Set your token via CLI flag, environment variable, or config file.

### Quota Limit Reached

```
❌ TestDino Execution Limit Reached
```

You've reached your monthly test execution quota. The error message shows:

- Your current plan and monthly limit
- How many executions you've used
- Remaining executions available
- When your quota resets

**Solutions:**

1. Upgrade your plan at [testdino.com/pricing](https://www.testdino.com/pricing)
2. Wait for your monthly quota to reset
3. Contact support if you need immediate assistance

Note: Tests will still run; only streaming to TestDino is affected.

### Connection Warnings

```
WebSocket connection failed, using HTTP fallback
```

This is normal. TestDino automatically uses HTTP fallback. Tests are not affected.

### Debug Mode

Enable detailed logging:

```bash
npx tdpw test --debug
```

## FAQ

**Q: How do I get a token?**
Sign up at [testdino.com](https://www.testdino.com) and follow the [Getting Started Guide](https://www.testdino.com/docs/getting-started).

**Q: Can I use TestDino with other Playwright reporters?**
Yes. TestDino works alongside HTML, JUnit, or any other reporter.

**Q: What happens if I reach my quota limit?**
Your tests continue to run as normal. TestDino will display a detailed message showing your usage and provide upgrade options. Only streaming to TestDino is paused until your quota resets.

**Q: What if TestDino server is unavailable?**
Tests run normally. Only event streaming is affected.

**Q: Does this work with Playwright VSCode extension?**
Yes. Configure TestDino in `playwright.config.ts` for VSCode integration.

## Support

- [Documentation](https://www.testdino.com/docs)
- [Getting Started](https://www.testdino.com/docs/getting-started)
- [Email Support](mailto:support@testdino.com)

---

Copyright 2025 TestDino. All rights reserved.
